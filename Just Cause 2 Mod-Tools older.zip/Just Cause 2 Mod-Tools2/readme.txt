Uses icons from the 'Fugue' pack available at:
  http://p.yusukekamiyamane.com/